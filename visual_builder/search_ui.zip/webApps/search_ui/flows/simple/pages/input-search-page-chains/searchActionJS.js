define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils00
) => {
  'use strict';

  const REST_SERVER = "https://i2b4iei3fcyflodmojwlkbyr5i.apigateway.eu-frankfurt-1.oci.customer-oci.com/psql";

  function highlightText(searchValue) {
    if (searchValue !== '') {
      let aElem = document.getElementsByClassName("opensearch-content");
      for (let i = 0; i < aElem.length; i++) {
        const content = aElem[i].innerHTML;
        const highlightedContent = content.replace(
          new RegExp(searchValue, 'gi'),
          '<span class="highlight">$&</span>'
        );
        aElem[i].innerHTML = highlightedContent;
      }
    }
  }


  function callPOST(url,json_body) {
      return new Promise(function (resolve, reject) {
          let xhr = new XMLHttpRequest();
          xhr.open("POST", url, true);
          xhr.setRequestHeader("Content-Type", "application/json");
          xhr.onload = function () {
              if (this.status >= 200 && this.status < 300) {
                  resolve(xhr.response);
              } else {
                  reject({
                      status: this.status,
                      statusText: xhr.statusText
                  });
              }
          };
          xhr.onerror = function () {
              reject({
                  status: this.status,
                  statusText: xhr.statusText
              });
          };
          let body = JSON.stringify(json_body)
          xhr.send(body);
      });
  }


  class searchActionJS extends ActionChain {

    longestCommonSubstring(str1, str2) {
      let n = str1.length;
      let m = str2.length;

      let lcs = [];
      for (let i = 0; i <= n; i++) {
        lcs[i] = [];
        for (let j = 0; j <= m; j++) {
          lcs[i][j] = 0;
        }
      }
      let result = "";
      let max = 0;
      for (let i = 0; i < n; i++) {
        for (let j = 0; j < m; j++) {
          if (str1[i] === str2[j]) {
            lcs[i + 1][j + 1] = lcs[i][j] + 1;
            if (lcs[i + 1][j + 1] > max) {
              max = lcs[i + 1][j + 1];
              result = str1.substring(i - max + 1, i + 1);
            }
          }
        }
      }
      return result;
    }


    highlightCommonSubString(response, hits) {
      hits.forEach((hit, index, array) => {
        console.log("highlightCommonSubString: " + hit.content);
        let common = this.longestCommonSubstring(response, hit.content);
        if (common.length > 20) {
          highlightText(common);
        }
      });
    }

    getLlmRequest(prompt) {
      prompt.replaceAll("\"", "'");

      let llmRequest = {
        "prompt": prompt
      };
      return llmRequest;
    }

    getLlmRequestForQuestion(question) {
      let prompt = 'You are a program answering with a simple clear response of one sentence.\n'
        + 'Question: ' + question;
      return this.getLlmRequest(prompt);
    }

    /**
     * searchActionJS
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.originButton 
     */
    async run(context, { originButton = 'search' }) {
      const { $page, $flow, $application } = context;

      $page.variables.originButton = originButton;
      $page.variables.ragResponse = "...";
      $page.variables.ragDocument = "";

      if (originButton === "generate") {
        $page.variables.opensearchHit = [];
        let llmRestResult = await callPOST( REST_SERVER + "/app/generate", this.getLlmRequestForQuestion($page.variables.searchText));
        /*
        let llmRestResult = await Actions.callRest(context, {
          endpoint: 'generate/postGenerate',
          body: this.getLlmRequestForQuestion($page.variables.searchText),
        });
        */
        $page.variables.ragResponse = llmRestResult;
        return;
      } else {
        let query = {
           "type": originButton,
           "question": $page.variables.searchText
        };
        let callRestOpensearchSearchResult = await callPOST( REST_SERVER + "/app/query", query);
        /*
        const callRestOpensearchSearchResult = await Actions.callRest(context, {
          endpoint: 'query/postQuery',
          responseBodyFormat: 'json',
          responseType: 'queryResponseType',
          body: query
        });
        */
        $page.variables.queryResponse = JSON.parse(callRestOpensearchSearchResult);
      }
      $page.variables.hitTotal = $page.variables.queryResponse.length;
      const truncateResult = await $page.functions.TruncateContent($page.variables.queryResponse);
      $page.variables.opensearchHit = truncateResult;
      // $page.variables.opensearchHit = $page.variables.queryResponse;

      if( originButton !== "rag" ) {
        setTimeout(function () {
          highlightText($page.variables.searchText);
        }, 200);
      } else {
        let prompt =
          `You are a person answering questions in a predefined json format based on 3 rules. The question is: "${$page.variables.searchText}". 
To respond to the question, follow the 3 following rules:
1. Answer the question only based on the json documents below
2. If the answer is not found in the content of the documents below, say "I do not find the answer in the documents." 
3. The answer has the following json format: { "found": "Boolean response found in document", "document": "Document where the response is found", "response": "response of the question"}

JSON document

[`;
        var bFirst = true;
        for (let res of truncateResult) {
          if (bFirst) {
            bFirst = false;
          } else {
            prompt += ",";
          }
          prompt +=
            `{ "Document": "${res.filename}",
"Context": "",
"Sentence": "${res.content}" }`;
        }
        prompt += ']';
        let llmRestResult = await callPOST( REST_SERVER + "/app/generate", this.getLlmRequest(prompt) );
        /*
        let llmRestResult = await Actions.callRest(context, {
          endpoint: 'generate/postGenerate',
          body: this.getLlmRequest(prompt),
        });
        */
        let jsonRes = llmRestResult;
        let objRes = { found: false };
        if( jsonRes.indexOf("I do not find the answer in the documents")<0 ) {
          try {
            objRes = JSON.parse(jsonRes);
          } catch(error) {
            // GenAI does not answer with JSON sometimes....
            objRes = { found: true, response: jsonRes, document: "-" };
          }
        }
        let response = "-";
        if (objRes.found) {
          $page.variables.ragResponse = objRes.response;
          if (objRes.document !== "-" ) {
            $page.variables.ragDocument = "Document: " + objRes.document;
          }
          this.highlightCommonSubString(objRes.response, $page.variables.queryResponse);
        }
        else {
          let llmRestResult2 = await callPOST( REST_SERVER + "/app/generate", this.getLlmRequestForQuestion($page.variables.searchText) );
          $page.variables.ragDocument = "I think that: " + llmRestResult2;
          $page.variables.ragResponse = "I do not find the answer in the documents.";
        }
      }
    }
  }

  return searchActionJS;
});
